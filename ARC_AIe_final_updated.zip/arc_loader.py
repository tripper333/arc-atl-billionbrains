
import json
import matplotlib.pyplot as plt
import numpy as np

class ARCTaskLoader:
    def __init__(self, json_path):
        with open(json_path, 'r') as f:
            self.data = json.load(f)

    def get_task(self, task_id):
        return self.data.get(task_id, None)

    def visualize_task(self, task, mode='train', index=0):
        pair = task[mode][index]
        input_grid = np.array(pair['input'])
        output_grid = np.array(pair['output'])

        fig, axs = plt.subplots(1, 2, figsize=(10, 5))
        axs[0].imshow(input_grid, cmap='tab20', interpolation='nearest')
        axs[0].set_title('Input')
        axs[1].imshow(output_grid, cmap='tab20', interpolation='nearest')
        axs[1].set_title('Output')
        plt.show()
