
import numpy as np

class Evaluator:
    def __init__(self):
        self.correct = 0
        self.total = 0
        self.latencies = []
        self.energies = []

    def evaluate(self, task_id, gt_output, prediction):
        is_correct = prediction == gt_output
        self.total += 1
        self.correct += int(is_correct)
        self.latencies.append(np.random.uniform(0.0001, 0.001))  # Simulated latency
        self.energies.append(np.random.uniform(0.00001, 0.0001))  # Simulated energy
        return {"task_id": task_id, "correct": is_correct}

    def summary(self):
        accuracy = self.correct / self.total if self.total > 0 else 0.0
        return {
            "accuracy": accuracy,
            "average_latency_sec": np.mean(self.latencies) if self.latencies else 0,
            "average_energy_joule": np.mean(self.energies) if self.energies else 0
        }
