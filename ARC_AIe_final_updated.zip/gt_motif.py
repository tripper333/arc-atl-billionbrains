
import matplotlib.pyplot as plt

class GTTracker:
    def __init__(self):
        self.g_t = []

    def update(self, val):
        self.g_t.append(val)

    def plot(self):
        plt.plot(self.g_t)
        plt.title('g(t) motif over training')
        plt.xlabel('Step')
        plt.ylabel('g(t)')
        plt.grid(True)
        plt.show()
