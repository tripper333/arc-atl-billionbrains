
import json
from arc_loader import ARCTaskLoader
from task_inference.meta_predictor import MetaPredictor
from evaluation.metrics import Evaluator
from submission.submission_generator import SubmissionBuilder
from visualizations.tensorboard_logging import TensorLogger

def run_all(data_path, output_path='submission.json', max_tasks=400):
    loader = ARCTaskLoader(data_path)
    predictor = MetaPredictor()
    evaluator = Evaluator()
    submitter = SubmissionBuilder()
    logger = TensorLogger()

    with open(data_path, 'r') as f:
        tasks = json.load(f)

    print(f"📦 Loaded {len(tasks)} tasks.")
    processed = 0

    for task_id, task in tasks.items():
        if processed >= max_tasks:
            break

        if 'test' not in task or not task['test']:
            print(f"⚠️ Skipping task {task_id}: No test outputs.")
            continue

        input_grid = task['test'][0]['input']
        prediction = predictor.predict(input_grid)

        # Check for ground truth
        if 'output' in task['test'][0]:
            gt_output = task['test'][0]['output']
            result = evaluator.evaluate(task_id, gt_output, prediction)
            logger.log_metrics(processed, result)
        else:
            print(f"🧠 Generated prediction for: {task_id} (no ground truth)")

        submitter.add_prediction(task_id, [prediction])
        processed += 1
        print(f"✅ Processed task: {task_id}")

    submitter.write_submission(output_path)

    summary = evaluator.summary()
    print("📊 Evaluation Summary:", summary)
    logger.log_metrics(processed, summary)

if __name__ == "__main__":
    run_all("arc-agi_evaluation_challenges.json", max_tasks=400)
