
# submission/submission_generator.py
import json
import os

class SubmissionBuilder:
    def __init__(self):
        self.entries = {}

    def add_prediction(self, task_id, prediction_list):
        self.entries[task_id] = prediction_list

    def write_submission(self, output_path='submission.json'):
        with open(output_path, 'w') as f:
            json.dump(self.entries, f)
