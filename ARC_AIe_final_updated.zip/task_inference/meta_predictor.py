
# task_inference/meta_predictor.py
import numpy as np
from task_inference import transformations

class MetaPredictor:
    def __init__(self):
        self.transforms = [
            transformations.horizontal_reflection,
            transformations.vertical_reflection,
            transformations.rotate_90,
            transformations.rotate_180,
            transformations.rotate_270,
            transformations.invert_colors,
            transformations.color_shift
        ]

    def predict(self, input_grid):
        attempt_1 = self.transforms[0](np.array(input_grid)).tolist()
        attempt_2 = self.transforms[1](np.array(input_grid)).tolist()
        return {"attempt_1": attempt_1, "attempt_2": attempt_2}
