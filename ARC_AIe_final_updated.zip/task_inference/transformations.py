
# task_inference/transformations.py
# Set of simple symbolic transformations

import numpy as np

def horizontal_reflection(grid):
    return np.fliplr(grid)

def vertical_reflection(grid):
    return np.flipud(grid)

def rotate_90(grid):
    return np.rot90(grid, k=1)

def rotate_180(grid):
    return np.rot90(grid, k=2)

def rotate_270(grid):
    return np.rot90(grid, k=3)

def invert_colors(grid, color_max=9):
    return color_max - grid

def color_shift(grid, shift=1, color_max=9):
    return (grid + shift) % (color_max + 1)
