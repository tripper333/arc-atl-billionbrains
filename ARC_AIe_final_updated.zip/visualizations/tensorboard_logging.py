
# visualizations/tensorboard_logging.py
from torch.utils.tensorboard import SummaryWriter
import numpy as np

class TensorLogger:
    def __init__(self, log_dir="runs/arc_aie"):
        self.writer = SummaryWriter(log_dir)

    def log_metrics(self, step, metrics):
        for key, value in metrics.items():
            self.writer.add_scalar(f"metrics/{key}", value, step)

    def log_dummy_data(self, step):
        # Ensures something is written to TensorBoard
        self.writer.add_scalar("metrics/debug_dummy", np.random.rand(), step)

    def log_3d_projection(self, step, name, data_3d):
        for i in range(data_3d.shape[0]):
            self.writer.add_image(f"{name}/slice_{i}", data_3d[i:i+1], step, dataformats='CHW')
